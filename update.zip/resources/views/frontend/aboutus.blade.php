@extends('layouts.main')

@section('content')

<div class="container">
    {!! $siteinfo->about_us !!}
</div>

@endsection
