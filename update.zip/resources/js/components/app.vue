<template>
    <div class="container-fluid">
        <Container />
    </div>
</template>

<script>
import Container from "./chat/Container";
export default {
    components: {
        Container: Container
    }
};
</script>

<style></style>
